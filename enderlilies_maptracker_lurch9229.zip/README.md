# EnderLiliesTracker
EmoTracker Package for Ender Lilies: Quietus of the Knights Randomizer.

This package contains a Map tracker, which features all the areas of the game, a world map variant, which has all locations on a single map, and 2 items only variants.

Entrance Randomization variant coming in the future 

Logic for the Verboten domain that involves going through blight is currently set to needing mask, or having 3 priestess' wishes, spellbound anklet 150+hp (this includes health boosts from Soiled Prayer Beads and Royal Aegis Curio (not the unused health relic)) and 5 relic slots, or having 150+hp, holy water, spellbound anklet and 6 relic slots along with movement needed to each check or 120P guardians wings (dodge upgrade) and dash (from Julius) with 3 wishes.

Logic to get through the Abyss Hell Run is set to needing 300+hp, spellbound anklet, ruined witches book, 6 wishes and 7 relic slots. This needs more vigorus testing so please let me know if you find over ways to get through gauntlet. Thanks.

Please address issues to this repository, or contact me on Discord Lurch9229#4849.

I hope you enjoy using this tracker alongside your rando playthroughs. Good Luck, Have Fun everyone.
